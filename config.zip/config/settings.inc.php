<?php
define('_DB_SERVER_', 'localhost');
define('_DB_NAME_', 'shopnew');
define('_DB_USER_', 'root');
define('_DB_PASSWD_', '');
define('_DB_PREFIX_', 'ps_');
define('_MYSQL_ENGINE_', 'InnoDB');
define('_PS_CACHING_SYSTEM_', 'CacheMemcache');
define('_PS_CACHE_ENABLED_', '0');
define('_COOKIE_KEY_', 'WcXTTNItzvX0bv69mAkgzprd5i7BgGZkF1vHRVEHndh6s9pHQY4ewqAr');
define('_COOKIE_IV_', 'cVi6pWdE');
define('_PS_CREATION_DATE_', '2016-08-10');
if (!defined('_PS_VERSION_'))
	define('_PS_VERSION_', '1.6.1.6');
define('_RIJNDAEL_KEY_', 'oM5tx5auXBgx2hjGS4SeOv6KFecXxjia');
define('_RIJNDAEL_IV_', '1DqFmc0gWQ3NegiZXfLZqA==');
