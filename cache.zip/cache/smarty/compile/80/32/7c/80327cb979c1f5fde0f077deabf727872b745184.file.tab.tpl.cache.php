<?php /* Smarty version Smarty-3.1.19, created on 2016-08-10 23:35:24
         compiled from "C:\xampp\htdocs\shop\modules\homefeatured\views\templates\hook\tab.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2705757ac008c4eb575-28441177%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '80327cb979c1f5fde0f077deabf727872b745184' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\modules\\homefeatured\\views\\templates\\hook\\tab.tpl',
      1 => 1466020876,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2705757ac008c4eb575-28441177',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ac008c549189_08055544',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ac008c549189_08055544')) {function content_57ac008c549189_08055544($_smarty_tpl) {?>
<li><a data-toggle="tab" href="#homefeatured" class="homefeatured"><?php echo smartyTranslate(array('s'=>'Popular','mod'=>'homefeatured'),$_smarty_tpl);?>
</a></li><?php }} ?>
