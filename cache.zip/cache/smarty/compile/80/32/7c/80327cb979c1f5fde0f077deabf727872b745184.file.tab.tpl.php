<?php /* Smarty version Smarty-3.1.19, created on 2016-08-11 00:02:10
         compiled from "C:\xampp\htdocs\shop\modules\homefeatured\views\templates\hook\tab.tpl" */ ?>
<?php /*%%SmartyHeaderCode:388157ac06d294f503-74102893%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '80327cb979c1f5fde0f077deabf727872b745184' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\modules\\homefeatured\\views\\templates\\hook\\tab.tpl',
      1 => 1466020876,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '388157ac06d294f503-74102893',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ac06d2953389_30144510',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ac06d2953389_30144510')) {function content_57ac06d2953389_30144510($_smarty_tpl) {?>
<li><a data-toggle="tab" href="#homefeatured" class="homefeatured"><?php echo smartyTranslate(array('s'=>'Popular','mod'=>'homefeatured'),$_smarty_tpl);?>
</a></li><?php }} ?>
