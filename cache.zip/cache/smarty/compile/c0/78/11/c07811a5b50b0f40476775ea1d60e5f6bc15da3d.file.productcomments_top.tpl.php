<?php /* Smarty version Smarty-3.1.19, created on 2016-08-11 04:39:25
         compiled from "C:\xampp\htdocs\shop\themes\default-bootstrap\modules\productcomments\productcomments_top.tpl" */ ?>
<?php /*%%SmartyHeaderCode:294957abe55d0b0846-20604394%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c07811a5b50b0f40476775ea1d60e5f6bc15da3d' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\themes\\default-bootstrap\\modules\\productcomments\\productcomments_top.tpl',
      1 => 1466020874,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '294957abe55d0b0846-20604394',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57abe55d0b0840_27309407',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57abe55d0b0840_27309407')) {function content_57abe55d0b0840_27309407($_smarty_tpl) {?><?php }} ?>
