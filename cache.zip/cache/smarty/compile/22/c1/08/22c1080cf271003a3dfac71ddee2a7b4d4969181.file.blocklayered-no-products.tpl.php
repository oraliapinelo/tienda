<?php /* Smarty version Smarty-3.1.19, created on 2016-08-11 04:39:23
         compiled from "C:\xampp\htdocs\shop\themes\default-bootstrap\modules\blocklayered\blocklayered-no-products.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1343757abe55b9a4a10-95546027%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '22c1080cf271003a3dfac71ddee2a7b4d4969181' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\themes\\default-bootstrap\\modules\\blocklayered\\blocklayered-no-products.tpl',
      1 => 1466020874,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1343757abe55b9a4a10-95546027',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57abe55b9a8891_85913269',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57abe55b9a8891_85913269')) {function content_57abe55b9a8891_85913269($_smarty_tpl) {?>
<div class="product_list">
	<p class="alert alert-warning"><?php echo smartyTranslate(array('s'=>'There are no products.','mod'=>'blocklayered'),$_smarty_tpl);?>
</p>
</div>
<?php }} ?>
