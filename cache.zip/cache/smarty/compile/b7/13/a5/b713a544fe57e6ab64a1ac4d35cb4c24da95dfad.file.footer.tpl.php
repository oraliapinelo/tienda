<?php /* Smarty version Smarty-3.1.19, created on 2016-08-11 00:43:34
         compiled from "C:\xampp\htdocs\shop\themes\plantillanew\footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:557ac108661d7a3-19086921%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b713a544fe57e6ab64a1ac4d35cb4c24da95dfad' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\themes\\plantillanew\\footer.tpl',
      1 => 1470894164,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '557ac108661d7a3-19086921',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'content_only' => 0,
    'HOOK_RIGHT_COLUMN' => 0,
    'HOOK_FOOTER' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ac10866254a3_40638189',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ac10866254a3_40638189')) {function content_57ac10866254a3_40638189($_smarty_tpl) {?>		<?php if (!$_smarty_tpl->tpl_vars['content_only']->value) {?>
  </div>        	
  
  
	    
                         <aside id="right_column"  class="span3 column right_home">   
                               <?php echo $_smarty_tpl->tpl_vars['HOOK_RIGHT_COLUMN']->value;?>

                                </aside>
                     
                              
    
  </div>
</div></div>
 <div class="footer-bg-mob">
                <footer class="container ">
                        
                                
                                        <div class="row modules">
                                                <?php echo $_smarty_tpl->tpl_vars['HOOK_FOOTER']->value;?>

                                        </div>
                                    
                         </div>
                </footer> 
      </div>          
                </div>
</div></div>
  <?php }?>

</body>
</html>
<?php }} ?>
