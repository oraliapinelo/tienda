<?php /* Smarty version Smarty-3.1.19, created on 2016-08-10 23:35:24
         compiled from "C:\xampp\htdocs\shop\modules\blockspecials\views\templates\hook\tab.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2715957ac008c8815c4-18717304%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7c9c87278b52bb14d74f06e5953554866e4b0406' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\modules\\blockspecials\\views\\templates\\hook\\tab.tpl',
      1 => 1466020876,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2715957ac008c8815c4-18717304',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ac008c8d74d4_17480797',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ac008c8d74d4_17480797')) {function content_57ac008c8d74d4_17480797($_smarty_tpl) {?>
<li><a data-toggle="tab" href="#blockspecials" class="blockspecials"><?php echo smartyTranslate(array('s'=>'Specials','mod'=>'blockspecials'),$_smarty_tpl);?>
</a></li>
<?php }} ?>
