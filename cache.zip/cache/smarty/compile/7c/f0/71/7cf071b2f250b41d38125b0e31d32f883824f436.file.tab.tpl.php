<?php /* Smarty version Smarty-3.1.19, created on 2016-08-11 00:02:10
         compiled from "C:\xampp\htdocs\shop\modules\blockbestsellers\views\templates\hook\tab.tpl" */ ?>
<?php /*%%SmartyHeaderCode:887857ac06d29d03a4-03649512%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7cf071b2f250b41d38125b0e31d32f883824f436' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\modules\\blockbestsellers\\views\\templates\\hook\\tab.tpl',
      1 => 1466020876,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '887857ac06d29d03a4-03649512',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ac06d29d4220_41912670',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ac06d29d4220_41912670')) {function content_57ac06d29d4220_41912670($_smarty_tpl) {?>
<li><a data-toggle="tab" href="#blockbestsellers" class="blockbestsellers"><?php echo smartyTranslate(array('s'=>'Best Sellers','mod'=>'blockbestsellers'),$_smarty_tpl);?>
</a></li><?php }} ?>
