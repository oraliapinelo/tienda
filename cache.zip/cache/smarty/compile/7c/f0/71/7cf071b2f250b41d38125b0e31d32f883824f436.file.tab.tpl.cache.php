<?php /* Smarty version Smarty-3.1.19, created on 2016-08-10 23:35:24
         compiled from "C:\xampp\htdocs\shop\modules\blockbestsellers\views\templates\hook\tab.tpl" */ ?>
<?php /*%%SmartyHeaderCode:783057ac008c6c7ee1-19919498%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7cf071b2f250b41d38125b0e31d32f883824f436' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\modules\\blockbestsellers\\views\\templates\\hook\\tab.tpl',
      1 => 1466020876,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '783057ac008c6c7ee1-19919498',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ac008c6fab64_50390453',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ac008c6fab64_50390453')) {function content_57ac008c6fab64_50390453($_smarty_tpl) {?>
<li><a data-toggle="tab" href="#blockbestsellers" class="blockbestsellers"><?php echo smartyTranslate(array('s'=>'Best Sellers','mod'=>'blockbestsellers'),$_smarty_tpl);?>
</a></li><?php }} ?>
