<?php /* Smarty version Smarty-3.1.19, created on 2016-08-11 00:03:05
         compiled from "C:\xampp\htdocs\shop\themes\theme593\footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2319957ac0709e3dad9-06560574%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '411e9fc4930ae162c11d3d41ff4a5c0dbc4f1b4b' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\themes\\theme593\\footer.tpl',
      1 => 1470891329,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2319957ac0709e3dad9-06560574',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'content_only' => 0,
    'HOOK_RIGHT_COLUMN' => 0,
    'HOOK_FOOTER' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ac0709e457d4_89263914',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ac0709e457d4_89263914')) {function content_57ac0709e457d4_89263914($_smarty_tpl) {?>		<?php if (!$_smarty_tpl->tpl_vars['content_only']->value) {?>
  </div>        	
  
  
	    
                         <aside id="right_column"  class="span3 column right_home">   
                               <?php echo $_smarty_tpl->tpl_vars['HOOK_RIGHT_COLUMN']->value;?>

                                </aside>
                     
                              
    
  </div>
</div></div>
 <div class="footer-bg-mob">
                <footer class="container ">
                        
                                
                                        <div class="row modules">
                                                <?php echo $_smarty_tpl->tpl_vars['HOOK_FOOTER']->value;?>

                                        </div>
                                    
                         </div>
                </footer> 
      </div>          
                </div>
</div></div>
  <?php }?>

</body>
</html>
<?php }} ?>
