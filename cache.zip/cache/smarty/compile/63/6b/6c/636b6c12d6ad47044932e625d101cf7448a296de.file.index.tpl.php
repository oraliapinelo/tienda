<?php /* Smarty version Smarty-3.1.19, created on 2016-08-11 00:03:05
         compiled from "C:\xampp\htdocs\shop\themes\theme593\index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2451257ac0709d53496-09411779%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '636b6c12d6ad47044932e625d101cf7448a296de' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\themes\\theme593\\index.tpl',
      1 => 1470891329,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2451257ac0709d53496-09411779',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'HOOK_HOME' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ac0709d5b193_29415559',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ac0709d5b193_29415559')) {function content_57ac0709d5b193_29415559($_smarty_tpl) {?>

<?php echo $_smarty_tpl->tpl_vars['HOOK_HOME']->value;?>

<?php }} ?>
