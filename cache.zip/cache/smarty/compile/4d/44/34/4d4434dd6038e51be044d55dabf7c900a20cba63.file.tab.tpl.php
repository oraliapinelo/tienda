<?php /* Smarty version Smarty-3.1.19, created on 2016-08-11 00:02:10
         compiled from "C:\xampp\htdocs\shop\modules\blocknewproducts\views\templates\hook\tab.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1758457ac06d28da1f4-00051492%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4d4434dd6038e51be044d55dabf7c900a20cba63' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\modules\\blocknewproducts\\views\\templates\\hook\\tab.tpl',
      1 => 1466020876,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1758457ac06d28da1f4-00051492',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ac06d28de070_58776689',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ac06d28de070_58776689')) {function content_57ac06d28de070_58776689($_smarty_tpl) {?>
<li><a data-toggle="tab" href="#blocknewproducts" class="blocknewproducts"><?php echo smartyTranslate(array('s'=>'New arrivals','mod'=>'blocknewproducts'),$_smarty_tpl);?>
</a></li>
<?php }} ?>
