<?php /*%%SmartyHeaderCode:1625557ac1084d1a322-71281938%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd359ae0ecb94840898ace143c2b0ac904eee77a4' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\themes\\plantillanew\\modules\\blockstore\\blockstore.tpl',
      1 => 1470894165,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1625557ac1084d1a322-71281938',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ac130808a402_35693114',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ac130808a402_35693114')) {function content_57ac130808a402_35693114($_smarty_tpl) {?><section id="stores_block_left" class="block  column_box">
	<h4><span>Nuestras tiendas</span><span class="column_icon_toggle"></span></h4>
	<div class="block_content blockstore toggle_content">
		<p class="store_image"><a href="http://localhost/shop/tiendas" title="Nuestras tiendas">
        <img src="http://localhost/shop/themes/plantillanew/img/store.jpg" alt="Nuestras tiendas"  /></a></p>
		<p>
			<a class="button" href="http://localhost/shop/tiendas" title="Nuestras tiendas">Descubra nuestras tiendas</a>
		</p>
	</div>
</section>
<!-- /Block stores module -->
<?php }} ?>
