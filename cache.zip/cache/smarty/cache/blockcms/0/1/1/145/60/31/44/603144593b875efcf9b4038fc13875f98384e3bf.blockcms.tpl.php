<?php /*%%SmartyHeaderCode:105957ac1083e798e9-19253934%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '603144593b875efcf9b4038fc13875f98384e3bf' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\themes\\plantillanew\\modules\\blockcms\\blockcms.tpl',
      1 => 1470894165,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '105957ac1083e798e9-19253934',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ac1307706489_52446633',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ac1307706489_52446633')) {function content_57ac1307706489_52446633($_smarty_tpl) {?>	<!-- Block CMS module -->
			<section class="block blockcms column_box span4">
			<h4><span>Información</span><span class="column_icon_toggle"></span></h4>
            <ul class="store_list toggle_content clearfix">
													<li><a href="http://localhost/shop/content/1-entrega" title="Envío">Envío</a></li>									<li><a href="http://localhost/shop/content/2-aviso-legal" title="Aviso legal">Aviso legal</a></li>									<li><a href="http://localhost/shop/content/3-terminos-y-condiciones-de-uso" title="Términos y condiciones">Términos y condiciones</a></li>									<li><a href="http://localhost/shop/content/4-sobre-nosotros" title="Sobre nosotros">Sobre nosotros</a></li>									<li><a href="http://localhost/shop/content/5-pago-seguro" title="Pago seguro">Pago seguro</a></li>								<li><a href="http://localhost/shop/tiendas" title="Nuestras tiendas">Nuestras tiendas</a></li>			</ul>
	</section>
		<!-- /Block CMS module -->
<?php }} ?>
