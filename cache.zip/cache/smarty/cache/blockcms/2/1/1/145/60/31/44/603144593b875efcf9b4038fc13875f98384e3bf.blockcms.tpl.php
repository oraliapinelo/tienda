<?php /*%%SmartyHeaderCode:105957ac1083e798e9-19253934%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '603144593b875efcf9b4038fc13875f98384e3bf' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\themes\\plantillanew\\modules\\blockcms\\blockcms.tpl',
      1 => 1470894165,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '105957ac1083e798e9-19253934',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ac1308721d91_58992271',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ac1308721d91_58992271')) {function content_57ac1308721d91_58992271($_smarty_tpl) {?>   
    <!-- MODULE Block footer -->
<section class="block blockcms_footer span4">
        <h4 class="toggle">Información</h4>
		<ul class="list-footer toggle_content clearfix">
			<li class="first_item"><a href="http://localhost/shop/bajamos-precios" title="Promociones especiales">Promociones especiales</a></li>			<li class="item"><a href="http://localhost/shop/nuevos-productos" title="Novedades">Novedades</a></li>
			<li class="item"><a href="http://localhost/shop/mas-vendido" title="¡Lo más vendido!">¡Lo más vendido!</a></li>			<li class="item"><a href="http://localhost/shop/tiendas" title="Nuestras tiendas">Nuestras tiendas</a></li>			<li class="item"><a href="http://localhost/shop/contactanos" title="Contacte con nosotros">Contacte con nosotros</a></li>
												<li class="item"><a href="http://localhost/shop/content/3-terminos-y-condiciones-de-uso" title="T&eacute;rminos y condiciones">T&eacute;rminos y condiciones</a></li>
																<li class="item"><a href="http://localhost/shop/content/4-sobre-nosotros" title="Sobre nosotros">Sobre nosotros</a></li>
										<li><a href="http://localhost/shop/mapa-web" title="sitemap">Mapa del sitio</a></li>
			
		</ul>
	
</section>
<section class="bottom_footer">&copy; 2016 Powered by <a target="_blank" href="http://www.prestashop.com">PrestaShop</a>&trade;</section>	<!-- /MODULE Block footer -->
<?php }} ?>
