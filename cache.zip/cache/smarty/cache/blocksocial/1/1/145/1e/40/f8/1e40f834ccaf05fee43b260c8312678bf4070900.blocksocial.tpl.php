<?php /*%%SmartyHeaderCode:194157ac1085191208-60163454%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1e40f834ccaf05fee43b260c8312678bf4070900' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\themes\\plantillanew\\modules\\blocksocial\\blocksocial.tpl',
      1 => 1470894165,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '194157ac1085191208-60163454',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ac130830ed28_33375469',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ac130830ed28_33375469')) {function content_57ac130830ed28_33375469($_smarty_tpl) {?><section class="block blocksocial">
	<h4>Síganos</h4>
	<ul class="toggle_content">
		<li class="facebook"><a href="http://www.facebook.com/prestashop">Facebook</a></li>		<li class="twitter"><a href="http://www.twitter.com/prestashop">Twitter</a></li>		<li class="rss"><a href="http://www.prestashop.com/blog/en/">RSS</a></li>	</ul>
</section><?php }} ?>
