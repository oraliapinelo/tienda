<?php /*%%SmartyHeaderCode:745657ac10848110f9-55541200%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b4eac471cc7c56de901b38cf870a236364a5189d' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\themes\\plantillanew\\modules\\blocknewproducts\\blocknewproducts.tpl',
      1 => 1470894165,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '745657ac10848110f9-55541200',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ac1307c78e41_47876420',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ac1307c78e41_47876420')) {function content_57ac1307c78e41_47876420($_smarty_tpl) {?><!-- MODULE Block new products -->
<section id="new-products_block_right" class="block products_block column_box">
	<h4 class="title_block"><span>Novedades</span> <span class="column_icon_toggle"></span></h4>
	<div class="block_content toggle_content">
			<ul class="products">
		        	<li class="shop_box clearfix first_item">
     
                	<a class="products_block_img" href="http://localhost/shop/joyeria/9-arete-perla-de-lado.html" title="Arete Perla De Lado"><img src="http://localhost/shop/25-medium_default/arete-perla-de-lado.jpg" alt="Arete Perla De Lado" /></a>
         
                <div >
            	<h5 class="s_title_block">
					<a class="product_link" href="http://localhost/shop/joyeria/9-arete-perla-de-lado.html" title="Arete Perla De Lado">Arete Perla De Lado</a>
            	</h5>
				            		<p class="product_desc">CÓDIGO: 116063</p>
                    <a href="http://localhost/shop/joyeria/9-arete-perla-de-lado.html" class="lnk_more">Leer más</a>
            	                </div>
            </li>
		        	<li class="shop_box clearfix item">
     
                	<a class="products_block_img" href="http://localhost/shop/joyeria/8-arete-kaiser.html" title="Arete Kaiser"><img src="http://localhost/shop/24-medium_default/arete-kaiser.jpg" alt="Arete Kaiser" /></a>
         
                <div >
            	<h5 class="s_title_block">
					<a class="product_link" href="http://localhost/shop/joyeria/8-arete-kaiser.html" title="Arete Kaiser">Arete Kaiser</a>
            	</h5>
				            		<p class="product_desc">CÓDIGO: 11603</p>
                    <a href="http://localhost/shop/joyeria/8-arete-kaiser.html" class="lnk_more">Leer más</a>
            	                </div>
            </li>
		        	<li class="shop_box clearfix item">
     
                	<a class="products_block_img" href="http://localhost/shop/vestidos-noche/4-vestido-estampado.html" title=""><img src="http://localhost/shop/10-medium_default/vestido-estampado.jpg" alt="" /></a>
         
                <div >
            	<h5 class="s_title_block">
					<a class="product_link" href="http://localhost/shop/vestidos-noche/4-vestido-estampado.html" title="Vestido estampado">Vestido estampado</a>
            	</h5>
				            		<p class="product_desc">Vestido de noche estampado con mangas rectas, cinturón...</p>
                    <a href="http://localhost/shop/vestidos-noche/4-vestido-estampado.html" class="lnk_more">Leer más</a>
            	                </div>
            </li>
		        	<li class="shop_box clearfix item">
     
                	<a class="products_block_img" href="http://localhost/shop/vestidos-verano/5-vestido-verano-estampado.html" title=""><img src="http://localhost/shop/12-medium_default/vestido-verano-estampado.jpg" alt="" /></a>
         
                <div >
            	<h5 class="s_title_block">
					<a class="product_link" href="http://localhost/shop/vestidos-verano/5-vestido-verano-estampado.html" title="Vestido de verano estampado">Vestido de verano...</a>
            	</h5>
				            		<p class="product_desc">Vestido largo estampado con tirantes finos ajustables....</p>
                    <a href="http://localhost/shop/vestidos-verano/5-vestido-verano-estampado.html" class="lnk_more">Leer más</a>
            	                </div>
            </li>
		        	<li class="shop_box clearfix item">
     
                	<a class="products_block_img" href="http://localhost/shop/vestidos-verano/6-vestido-verano-estampado.html" title=""><img src="http://localhost/shop/16-medium_default/vestido-verano-estampado.jpg" alt="" /></a>
         
                <div >
            	<h5 class="s_title_block">
					<a class="product_link" href="http://localhost/shop/vestidos-verano/6-vestido-verano-estampado.html" title="Vestido de verano estampado">Vestido de verano...</a>
            	</h5>
				            		<p class="product_desc">Vestido sin mangas de gasa hasta la rodilla. Escote en V...</p>
                    <a href="http://localhost/shop/vestidos-verano/6-vestido-verano-estampado.html" class="lnk_more">Leer más</a>
            	                </div>
            </li>
		        	<li class="shop_box clearfix item">
     
                	<a class="products_block_img" href="http://localhost/shop/vestidos-verano/7-vestido-estampado-gasa.html" title=""><img src="http://localhost/shop/20-medium_default/vestido-estampado-gasa.jpg" alt="" /></a>
         
                <div >
            	<h5 class="s_title_block">
					<a class="product_link" href="http://localhost/shop/vestidos-verano/7-vestido-estampado-gasa.html" title="Vestido de gasa estampado">Vestido de gasa...</a>
            	</h5>
				            		<p class="product_desc">Vestido sin mangas hasta la rodilla, tejido de gasa...</p>
                    <a href="http://localhost/shop/vestidos-verano/7-vestido-estampado-gasa.html" class="lnk_more">Leer más</a>
            	                </div>
            </li>
		        	<li class="shop_box clearfix item">
     
                	<a class="products_block_img" href="http://localhost/shop/blusas/2-blusa.html" title=""><img src="http://localhost/shop/7-medium_default/blusa.jpg" alt="" /></a>
         
                <div >
            	<h5 class="s_title_block">
					<a class="product_link" href="http://localhost/shop/blusas/2-blusa.html" title="Blusa">Blusa</a>
            	</h5>
				            		<p class="product_desc">Blusa de manga corta con detalle drapeado muy femenino en...</p>
                    <a href="http://localhost/shop/blusas/2-blusa.html" class="lnk_more">Leer más</a>
            	                </div>
            </li>
		        	<li class="shop_box clearfix last_item">
     
                	<a class="products_block_img" href="http://localhost/shop/vestidos-informales/3-vestido-estampado.html" title=""><img src="http://localhost/shop/8-medium_default/vestido-estampado.jpg" alt="" /></a>
         
                <div >
            	<h5 class="s_title_block">
					<a class="product_link" href="http://localhost/shop/vestidos-informales/3-vestido-estampado.html" title="Vestido estampado">Vestido estampado</a>
            	</h5>
				            		<p class="product_desc">Vestido doble estampado 100% algodón. Top de rayas negras...</p>
                    <a href="http://localhost/shop/vestidos-informales/3-vestido-estampado.html" class="lnk_more">Leer más</a>
            	                </div>
            </li>
				</ul>
		<a href="http://localhost/shop/nuevos-productos" title="Todas los nuevos productos" class="button_large">Todas los nuevos productos</a>
		</div>
</section>
<!-- /MODULE Block new products --><?php }} ?>
