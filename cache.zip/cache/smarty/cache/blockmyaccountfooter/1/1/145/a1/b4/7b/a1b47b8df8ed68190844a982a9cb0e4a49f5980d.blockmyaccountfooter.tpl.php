<?php /*%%SmartyHeaderCode:2872857ac10859690d1-78095914%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a1b47b8df8ed68190844a982a9cb0e4a49f5980d' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\themes\\plantillanew\\modules\\blockmyaccountfooter\\blockmyaccountfooter.tpl',
      1 => 1470894165,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2872857ac10859690d1-78095914',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ac130898b125_01719136',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ac130898b125_01719136')) {function content_57ac130898b125_01719136($_smarty_tpl) {?><!-- Block myaccount module -->
<section class="block blockmyaccountfooter span4">
	<h4>Mi cuenta</h4>
		<ul class="list-footer toggle_content clearfix">
			<li><a href="http://localhost/shop/historial-compra" title="List of my orders" rel="nofollow">Mis compras</a></li>
						<li><a href="http://localhost/shop/albaran" title="List of my credit slips" rel="nofollow">Mis vales descuento</a></li>
			<li><a href="http://localhost/shop/direcciones" title="List of my addresses" rel="nofollow">Mis direcciones</a></li>
			<li><a href="http://localhost/shop/datos-personales" title="Administrar mi información personal" rel="nofollow">Mis datos personales</a></li>
						
		</ul>    		
</section>
<!-- /Block myaccount module -->
<?php }} ?>
