<?php /*%%SmartyHeaderCode:658057ac108360d2e8-60587836%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd67aafc4a51150d9e31bbd2bbb55ba3fd58ccd50' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\themes\\plantillanew\\modules\\blocktopmenu\\blocktopmenu.tpl',
      1 => 1470894165,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '658057ac108360d2e8-60587836',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ac1306d99bf9_35415952',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ac1306d99bf9_35415952')) {function content_57ac1306d99bf9_35415952($_smarty_tpl) {?><div id="menu-wrap">  
	<ul id="menu-custom">
			<li class="sfHoverForce"><a href="http://localhost/shop/12-joyeria" title="Joyeria">Joyeria</a></li>
					</ul>
	</div>
<?php }} ?>
