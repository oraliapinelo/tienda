<?php /*%%SmartyHeaderCode:1859057ac1084a5b079-99310133%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '59f7e9c02287b9d143a8617f35cd5a1581dceaac' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\themes\\plantillanew\\modules\\blockspecials\\blockspecials.tpl',
      1 => 1470894165,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1859057ac1084a5b079-99310133',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ac1307e16fa1_29940927',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ac1307e16fa1_29940927')) {function content_57ac1307e16fa1_29940927($_smarty_tpl) {?><!-- MODULE Block specials -->
    <section id="specials" class="block products_block column_box">
	<h4><span>Promociones especiales</span><span class="column_icon_toggle"></span></h4>
	<div class="block_content toggle_content">
		<ul>
			<li class="shop_box  clearfix">
				<a class="products_block_img" href="http://localhost/shop/vestidos-verano/5-vestido-verano-estampado.html"><img src="http://localhost/shop/12-small_default/vestido-verano-estampado.jpg" alt="" title="Vestido de verano estampado" /></a>
				<div>
				<h5><a class="product_link" href="http://localhost/shop/vestidos-verano/5-vestido-verano-estampado.html" title="Vestido de verano estampado">Vestido de verano estampado</a></h5>
				<p class="product_desc">Vestido largo estampado con tirantes...</p>                
            	<span class="price">33,62 $</span>
            																									<span class="reduction price">(-5%)</span>
															
				<span class="price-discount price">35,39 $</span>
				</div>
			</li>
		</ul>
		<a class="button_large" href="http://localhost/shop/bajamos-precios" title="Todas los promociones especiales">Todas los promociones especiales</a>
	</div>
</section>
<!-- /MODULE Block specials --><?php }} ?>
