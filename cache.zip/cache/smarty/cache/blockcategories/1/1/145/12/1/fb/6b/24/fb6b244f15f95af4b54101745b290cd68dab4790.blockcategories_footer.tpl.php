<?php /*%%SmartyHeaderCode:2065057ac10852e1152-64607576%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fb6b244f15f95af4b54101745b290cd68dab4790' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\themes\\plantillanew\\modules\\blockcategories\\blockcategories_footer.tpl',
      1 => 1470894165,
      2 => 'file',
    ),
    'e187e65bd37441e38d19987e808d0a6e906c6c97' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\themes\\plantillanew\\modules\\blockcategories\\category-tree-branch.tpl',
      1 => 1470894165,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2065057ac10852e1152-64607576',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ac13085492a9_39471270',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ac13085492a9_39471270')) {function content_57ac13085492a9_39471270($_smarty_tpl) {?><!-- Block categories module -->
<section class="block block_category_footer">
        <h4>Categorías</h4>
		<ul class="toggle_content list-footer tree dhtml">
									
<li class="last">
	<a href="http://localhost/shop/12-joyeria" class="selected" title="">Joyeria</a>
	</li>

											</ul>
</section>
<!-- /Block categories module -->
<?php }} ?>
