<?php /*%%SmartyHeaderCode:2696257ac10839be8c6-78034539%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c2ab3e39ad5f6c92de8d86b610dc1829e0664161' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\themes\\plantillanew\\modules\\blockcategories\\blockcategories.tpl',
      1 => 1470894165,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2696257ac10839be8c6-78034539',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ac130723ba67_47437918',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ac130723ba67_47437918')) {function content_57ac130723ba67_47437918($_smarty_tpl) {?><!-- Block categories module -->
<section  id="categories_block_left"  class="column_box block">
	<h4><span>Categorías</span><span class="column_icon_toggle"></span></h4>
		<ul class="toggle_content tree dhtml store_list">
				</ul>
		
		<script type="text/javascript">
		// <![CDATA[
			// we hide the tree only if JavaScript is activated
			$('div#categories_block_left ul.dhtml').hide();
		// ]]>
		</script>
</section>
<!-- /Block categories module -->
<?php }} ?>
