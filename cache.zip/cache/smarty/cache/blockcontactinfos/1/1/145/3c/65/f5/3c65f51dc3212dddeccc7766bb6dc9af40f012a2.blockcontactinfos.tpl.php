<?php /*%%SmartyHeaderCode:206557ac1085d9b554-29622830%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3c65f51dc3212dddeccc7766bb6dc9af40f012a2' => 
    array (
      0 => 'C:\\xampp\\htdocs\\shop\\themes\\plantillanew\\modules\\blockcontactinfos\\blockcontactinfos.tpl',
      1 => 1470894165,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '206557ac1085d9b554-29622830',
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_57ac1308bf44b7_04777960',
  'has_nocache_code' => false,
  'cache_lifetime' => 31536000,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57ac1308bf44b7_04777960')) {function content_57ac1308bf44b7_04777960($_smarty_tpl) {?><section class="block blockcontactinfos span4">
	<h4>Contacte con nosotros</h4>
	<ul class="toggle_content">
		<li><strong>My Company</strong></li>		<li>42 Puffin street
12345 Puffinville
France</li>		<li>Tel: 0123-456-789</li>		<li>Email: <a href="&#109;&#97;&#105;&#108;&#116;&#111;&#58;%73%61%6c%65%73@%79%6f%75%72%63%6f%6d%70%61%6e%79.%63%6f%6d" >&#x73;&#x61;&#x6c;&#x65;&#x73;&#x40;&#x79;&#x6f;&#x75;&#x72;&#x63;&#x6f;&#x6d;&#x70;&#x61;&#x6e;&#x79;&#x2e;&#x63;&#x6f;&#x6d;</a></li>	</ul>
</section>
<?php }} ?>
